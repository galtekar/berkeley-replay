#ifndef OKCLIENT_H
#define OKCLIENT_H

extern int okclient(char *);

#endif
