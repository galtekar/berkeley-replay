/* sysdep: -shortsetgroups */
