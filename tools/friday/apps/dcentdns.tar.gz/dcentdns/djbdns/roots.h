#ifndef ROOTS_H
#define ROOTS_H

extern int roots(char *,char *);
extern int roots_same(char *,char *);
extern int roots_init(void);
extern int roots_init2(char servers[64]);

#endif
